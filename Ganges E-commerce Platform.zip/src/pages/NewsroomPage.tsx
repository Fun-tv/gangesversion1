import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { Button } from "../components/ui/button";
import { Calendar, ArrowRight, BookOpen, TrendingUp, Globe2, Sparkles } from "lucide-react";
import { motion } from "motion/react";

export default function NewsroomPage() {
  const fadeInUp = {
    initial: { opacity: 0, y: 30 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.6 }
  };

  const featuredPosts = [
    {
      title: "The $4.35 Billion Handicrafts Export Story: How Traditional Indian Crafts Are Conquering Global Markets",
      category: "Market Insights",
      date: "October 2025",
      excerpt: "Explore how India's handicraft sector is experiencing unprecedented growth with 25.7% annual expansion, bringing authentic craftsmanship to discerning global consumers.",
      image: "🎨",
      color: "from-blue-500 to-blue-600"
    },
    {
      title: "From Zoho to the World: How Indian SaaS Companies Are Redefining Global Software",
      category: "Business Success",
      date: "October 2025",
      excerpt: "Discover the rise of Indian SaaS unicorns and how companies like Zoho, Freshworks, and others are competing on the global stage with world-class products.",
      image: "💻",
      color: "from-purple-500 to-purple-600"
    },
    {
      title: "Ayurveda Goes Digital: The Rise of Online Traditional Healing Education",
      category: "Cultural Deep Dive",
      date: "September 2025",
      excerpt: "The ancient science of Ayurveda finds new life online, making traditional healing wisdom accessible to seekers worldwide through verified digital platforms.",
      image: "🌿",
      color: "from-green-500 to-green-600"
    },
    {
      title: "Beyond the Golden Triangle: Unexplored India for International Travelers",
      category: "Travel & Experience",
      date: "September 2025",
      excerpt: "Journey beyond the tourist trail to discover India's hidden gems - from pristine Himalayan villages to coastal sanctuaries and spiritual retreats.",
      image: "🏔️",
      color: "from-amber-500 to-amber-600"
    }
  ];

  const categories = [
    { name: "Artisan Spotlights", icon: Sparkles, desc: "Traditional craftspeople and their timeless techniques" },
    { name: "Market Insights", icon: TrendingUp, desc: "India's export trends and opportunities" },
    { name: "Cultural Deep Dives", icon: Globe2, desc: "Festivals, traditions, and spiritual practices explained" },
    { name: "Business Success Stories", icon: BookOpen, desc: "Indian companies making global impact" }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1e3a8a] via-[#1e3a8a] to-[#1a1a2e] text-white py-20 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
            backgroundSize: '40px 40px'
          }}></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            className="text-center max-w-4xl mx-auto"
            {...fadeInUp}
          >
            <motion.div 
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
              className="w-20 h-20 bg-[#ff9933] rounded-full flex items-center justify-center mx-auto mb-6"
            >
              <BookOpen className="h-10 w-10 text-white" />
            </motion.div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl mb-6">
              Newsroom
            </h1>
            <p className="text-2xl text-white/90 leading-relaxed">
              Stories from the Bridge Between Cultures
            </p>
            <p className="text-lg text-white/80 max-w-3xl mx-auto mt-4">
              Discover the rich tapestry of Indian culture, business, and innovation through our curated content. From artisan spotlights to market insights, our blog celebrates India's contributions to the global marketplace.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Featured Content */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeInUp} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl mb-6 text-[#1e3a8a]">
              Recent Posts
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Latest insights and stories from India's vibrant marketplace
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {featuredPosts.map((post, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card className="h-full hover:shadow-2xl transition-all border-2 border-transparent hover:border-[#1e3a8a]/20 overflow-hidden">
                  <div className={`h-2 bg-gradient-to-r ${post.color}`}></div>
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <Badge variant="secondary">{post.category}</Badge>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        {post.date}
                      </div>
                    </div>
                    <div className="text-5xl mb-4">{post.image}</div>
                    <CardTitle className="text-2xl text-[#1e3a8a] mb-4">{post.title}</CardTitle>
                    <CardDescription className="text-base leading-relaxed">{post.excerpt}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button variant="outline" className="w-full group">
                      Read More
                      <ArrowRight className="h-4 w-4 ml-2 group-hover:ml-3 transition-all" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Content Categories */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div {...fadeInUp} className="text-center mb-16">
            <h2 className="text-4xl sm:text-5xl mb-6 text-[#1e3a8a]">
              Featured Content Categories
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Explore our curated collections
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-8">
            {categories.map((category, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
                whileHover={{ y: -5 }}
                className="bg-white p-8 rounded-2xl border border-border shadow-lg hover:shadow-xl transition-all"
              >
                <div className="flex items-start gap-6">
                  <div className="w-14 h-14 bg-gradient-to-br from-[#1e3a8a] to-[#ff9933] rounded-xl flex items-center justify-center flex-shrink-0">
                    <category.icon className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="mb-3 text-[#1e3a8a]">{category.name}</h3>
                    <p className="text-muted-foreground leading-relaxed">{category.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Additional Topics */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                title: "Artisan Spotlights",
                topics: [
                  "Traditional craftspeople and their timeless techniques",
                  "Modern adaptations of ancient arts",
                  "Regional specialties and cultural significance"
                ]
              },
              {
                title: "Market Insights",
                topics: [
                  "India's export trends and opportunities",
                  "Global demand for Indian products and services",
                  "Industry analysis and growth projections"
                ]
              },
              {
                title: "Travel & Experience",
                topics: [
                  "Hidden gems across India",
                  "Seasonal travel recommendations",
                  "Cultural etiquette and travel tips"
                ]
              }
            ].map((section, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.5 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-[#1e3a8a]">{section.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {section.topics.map((topic, idx) => (
                        <li key={idx} className="flex gap-3">
                          <span className="text-[#ff9933] mt-1">•</span>
                          <span className="text-muted-foreground">{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Subscribe CTA */}
      <section className="py-20 bg-gradient-to-br from-[#1e3a8a] to-[#1a1a2e] text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div {...fadeInUp}>
            <h2 className="text-4xl sm:text-5xl mb-6">
              Stay Connected
            </h2>
            <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto leading-relaxed">
              Subscribe to receive weekly insights about India's evolving marketplace and cultural landscape
            </p>
            <Button 
              size="lg"
              className="bg-[#ff9933] hover:bg-[#ff9933]/90 text-white px-8 py-6 text-lg"
              onClick={() => window.location.href = "mailto:gangescompany@gmail.com?subject=Newsletter Subscription"}
            >
              Subscribe to Newsletter
            </Button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
